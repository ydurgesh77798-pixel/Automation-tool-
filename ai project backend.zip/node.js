const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Supabase configuration for backend verification
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY // Use service role key for backend
);

// Middleware
app.use(cors({
    origin: [
        'https://your-netlify-app.netlify.app',
        'http://localhost:3000',
        'http://localhost:5500'
    ],
    credentials: true
}));
app.use(express.json());

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Auth middleware to verify JWT token
async function verifyAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'No token provided' });
    }
    
    const token = authHeader.split(' ')[1];
    
    try {
        const { data: { user }, error } = await supabase.auth.getUser(token);
        
        if (error || !user) {
            return res.status(401).json({ error: 'Invalid token' });
        }
        
        req.user = user;
        next();
    } catch (error) {
        console.error('Auth error:', error);
        return res.status(401).json({ error: 'Authentication failed' });
    }
}

// Generate endpoint
app.post('/generate', verifyAuth, async (req, res) => {
    try {
        const { input, softwareType } = req.body;
        const userId = req.user.id;
        
        if (!input || !softwareType) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        
        // Check user plan from database
        const { data: userData, error: userError } = await supabase
            .from('users')
            .select('plan')
            .eq('id', userId)
            .single();
        
        if (userError) {
            console.error('Error fetching user plan:', userError);
        }
        
        const userPlan = userData?.plan || 'free';
        
        // Check character limit for free users
        if (userPlan === 'free' && input.length > 500) {
            return res.status(403).json({ error: 'Free plan limited to 500 characters. Upgrade to Pro!' });
        }
        
        // Create prompt based on software type
        const prompt = `You are an expert content creator specializing in ${softwareType}. 
        Create a comprehensive, professional document based on this project description: "${input}"
        
        Requirements:
        1. Format the content appropriately for ${softwareType}
        2. Include clear sections with headers
        3. Add practical implementation details
        4. Make it ready to use immediately
        5. Keep it professional and well-structured
        
        Generate the content now:`;
        
        // Call Gemini API
        const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const generatedText = response.text();
        
        res.json({
            success: true,
            result: generatedText,
            userPlan: userPlan
        });
        
    } catch (error) {
        console.error('Generation error:', error);
        res.status(500).json({ error: 'AI generation failed. Please try again.' });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'AI Project Generator API'
    });
});

// Get user info endpoint
app.get('/user', verifyAuth, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('users')
            .select('*')
            .eq('id', req.user.id)
            .single();
        
        if (error) throw error;
        
        res.json({ user: data });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch user data' });
    }
});

// Update user plan endpoint
app.post('/update-plan', verifyAuth, async (req, res) => {
    try {
        const { plan } = req.body;
        
        const { data, error } = await supabase
            .from('users')
            .update({ plan: plan, updated_at: new Date().toISOString() })
            .eq('id', req.user.id)
            .select();
        
        if (error) throw error;
        
        res.json({ success: true, user: data[0] });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update plan' });
    }
});

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📍 Health check: http://localhost:${PORT}/health`);
});