// Supabase Configuration
const SUPABASE_URL = 'https://your-supabase-url.supabase.co';
const SUPABASE_ANON_KEY = 'your-supabase-anon-key';
const BACKEND_URL = 'https://your-backend.onrender.com';

// Initialize Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Global state
let currentUser = null;
let userPlan = 'free';
let currentOutput = '';

// DOM Elements
const elements = {
    sidebar: document.getElementById('sidebar'),
    mobileMenuToggle: document.getElementById('mobileMenuToggle'),
    authSection: document.getElementById('authSection'),
    generateView: document.getElementById('generateView'),
    historyView: document.getElementById('historyView'),
    pricingView: document.getElementById('pricingView'),
    settingsView: document.getElementById('settingsView'),
    loginCard: document.getElementById('loginCard'),
    signupCard: document.getElementById('signupCard'),
    loginForm: document.getElementById('loginForm'),
    signupForm: document.getElementById('signupForm'),
    generateBtn: document.getElementById('generateBtn'),
    projectInput: document.getElementById('projectInput'),
    softwareType: document.getElementById('softwareType'),
    voiceInputBtn: document.getElementById('voiceInputBtn'),
    fileUploadBtn: document.getElementById('fileUploadBtn'),
    txtFileInput: document.getElementById('txtFileInput'),
    outputContent: document.getElementById('outputContent'),
    outputButtons: document.getElementById('outputButtons'),
    copyOutputBtn: document.getElementById('copyOutputBtn'),
    downloadOutputBtn: document.getElementById('downloadOutputBtn'),
    historyList: document.getElementById('historyList'),
    settingsPlan: document.getElementById('settingsPlan'),
    settingsEmail: document.getElementById('settingsEmail'),
    changePasswordBtn: document.getElementById('changePasswordBtn'),
    newPassword: document.getElementById('newPassword'),
    logoutBtn: document.getElementById('logoutBtn'),
    settingsLogoutBtn: document.getElementById('settingsLogoutBtn'),
    settingsUpgradeBtn: document.getElementById('settingsUpgradeBtn'),
    planIndicator: document.getElementById('planIndicator')
};

// Toast Notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Auth Functions
async function signUp(name, email, password) {
    const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
            data: { full_name: name, plan: 'free' }
        }
    });
    
    if (error) throw error;
    
    // Create user metadata in database
    const { error: dbError } = await supabase
        .from('users')
        .insert([{ id: data.user.id, email, full_name: name, plan: 'free' }]);
    
    if (dbError) console.error('DB insert error:', dbError);
    
    return data;
}

async function login(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
    });
    if (error) throw error;
    return data;
}

async function logout() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
}

async function changePassword(newPassword) {
    const { error } = await supabase.auth.updateUser({
        password: newPassword
    });
    if (error) throw error;
}

// Load user profile and plan
async function loadUserProfile() {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
        currentUser = user;
        const { data } = await supabase
            .from('users')
            .select('plan')
            .eq('id', user.id)
            .single();
        
        userPlan = data?.plan || 'free';
        updateUIForPlan();
        
        document.getElementById('sidebarUserName').textContent = user.user_metadata?.full_name || user.email;
        document.getElementById('settingsEmail').textContent = user.email;
        document.getElementById('settingsPlan').textContent = userPlan === 'free' ? 'Free' : 'Pro';
        
        if (elements.planIndicator) {
            elements.planIndicator.innerHTML = userPlan === 'free' 
                ? '<i class="fas fa-star"></i> Free Plan - 500 char limit' 
                : '<i class="fas fa-crown"></i> Pro Plan - Unlimited';
        }
    }
}

// Update UI based on plan
function updateUIForPlan() {
    const inputLimit = userPlan === 'free' ? 500 : Infinity;
    elements.projectInput.maxLength = inputLimit;
    
    if (userPlan === 'free') {
        elements.projectInput.placeholder = `Free plan: ${inputLimit} character limit. Upgrade for unlimited!`;
    }
}

// AI Generation
async function generateProject() {
    const inputText = elements.projectInput.value.trim();
    const softwareType = elements.softwareType.value;
    
    if (!inputText) {
        showToast('Please enter a project description', 'error');
        return;
    }
    
    if (userPlan === 'free' && inputText.length > 500) {
        showToast('Free plan limited to 500 characters. Upgrade to Pro!', 'error');
        return;
    }
    
    // Show loading
    elements.outputContent.innerHTML = '<div class="loading-spinner"></div>';
    
    try {
        const response = await fetch(`${BACKEND_URL}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`
            },
            body: JSON.stringify({
                input: inputText,
                softwareType: softwareType,
                userId: currentUser?.id
            })
        });
        
        if (!response.ok) throw new Error('Generation failed');
        
        const data = await response.json();
        currentOutput = data.result;
        
        elements.outputContent.innerHTML = `<div class="result-text">${data.result.replace(/\n/g, '<br>')}</div>`;
        elements.outputButtons.classList.remove('hidden');
        
        // Save to database
        await supabase.from('projects').insert([{
            user_id: currentUser.id,
            input_text: inputText,
            ai_result: data.result,
            software_type: softwareType,
            created_at: new Date()
        }]);
        
        showToast('Project generated successfully!', 'success');
    } catch (error) {
        console.error('Generation error:', error);
        elements.outputContent.innerHTML = '<p class="placeholder">❌ Failed to generate. Please try again.</p>';
        showToast('Generation failed: ' + error.message, 'error');
    }
}

// Load History
async function loadHistory() {
    if (!currentUser) return;
    
    const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', currentUser.id)
        .order('created_at', { ascending: false });
    
    if (error) {
        elements.historyList.innerHTML = '<p>Error loading history</p>';
        return;
    }
    
    if (data.length === 0) {
        elements.historyList.innerHTML = '<p>No projects yet. Start generating!</p>';
        return;
    }
    
    elements.historyList.innerHTML = data.map(project => `
        <div class="history-item">
            <div class="history-header">
                <strong>${project.software_type}</strong>
                <small>${new Date(project.created_at).toLocaleString()}</small>
            </div>
            <div class="history-input"><strong>Input:</strong> ${project.input_text.substring(0, 100)}...</div>
            <div class="history-output"><strong>Output:</strong> ${project.ai_result.substring(0, 150)}...</div>
        </div>
    `).join('');
}

// Voice Input
function initVoiceInput() {
    if (!('webkitSpeechRecognition' in window)) {
        showToast('Voice input not supported in this browser', 'error');
        return;
    }
    
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;
    
    recognition.onstart = () => showToast('Listening... Speak now', 'info');
    recognition.onresult = (event) => {
        const text = event.results[0][0].transcript;
        elements.projectInput.value = text;
        showToast('Voice input added!', 'success');
    };
    recognition.onerror = () => showToast('Voice recognition failed', 'error');
    
    recognition.start();
}

// File Upload
function handleFileUpload(file) {
    if (file.type !== 'text/plain') {
        showToast('Please upload a .txt file', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        elements.projectInput.value = e.target.result;
        showToast('File loaded successfully!', 'success');
    };
    reader.onerror = () => showToast('Failed to read file', 'error');
    reader.readAsText(file);
}

// Copy to Clipboard
function copyToClipboard() {
    navigator.clipboard.writeText(currentOutput);
    showToast('Copied to clipboard!', 'success');
}

// Download as PDF
function downloadAsPDF() {
    const element = elements.outputContent.cloneNode(true);
    element.style.padding = '20px';
    element.style.background = 'white';
    element.style.color = 'black';
    
    html2pdf().from(element).save('ai-generated-project.pdf');
    showToast('Downloading PDF...', 'success');
}

// Razorpay Payment
function initPayment(plan) {
    const options = {
        key: 'YOUR_RAZORPAY_KEY',
        amount: plan === 'monthly' ? 9900 : plan === '6months' ? 19900 : 29900,
        currency: 'INR',
        name: 'AI Project Generator',
        description: `${plan} Plan Subscription`,
        handler: async (response) => {
            // Update user plan in database
            const { error } = await supabase
                .from('users')
                .update({ plan: 'pro' })
                .eq('id', currentUser.id);
            
            if (!error) {
                userPlan = 'pro';
                updateUIForPlan();
                showToast('Upgrade successful! 🎉', 'success');
                loadUserProfile();
            }
        },
        prefill: {
            email: currentUser.email
        }
    };
    
    const rzp = new Razorpay(options);
    rzp.open();
}

// Navigation
function showView(viewName) {
    elements.authSection.classList.add('hidden');
    elements.generateView.classList.add('hidden');
    elements.historyView.classList.add('hidden');
    elements.pricingView.classList.add('hidden');
    elements.settingsView.classList.add('hidden');
    
    if (viewName === 'generate') elements.generateView.classList.remove('hidden');
    else if (viewName === 'history') {
        elements.historyView.classList.remove('hidden');
        loadHistory();
    }
    else if (viewName === 'pricing') elements.pricingView.classList.remove('hidden');
    else if (viewName === 'settings') elements.settingsView.classList.remove('hidden');
    
    // Update active nav
    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-view="${viewName}"]`)?.classList.add('active');
}

// Auth State Listener
supabase.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN') {
        await loadUserProfile();
        elements.authSection.classList.add('hidden');
        showView('generate');
        
        // Update header
        document.getElementById('loginHeaderBtn').classList.add('hidden');
        document.getElementById('signupHeaderBtn').classList.add('hidden');
        document.getElementById('profileIcon').classList.remove('hidden');
        
        showToast('Welcome back!', 'success');
    } else if (event === 'SIGNED_OUT') {
        currentUser = null;
        elements.authSection.classList.remove('hidden');
        elements.loginCard.classList.remove('hidden');
        elements.signupCard.classList.add('hidden');
        
        document.getElementById('loginHeaderBtn').classList.remove('hidden');
        document.getElementById('signupHeaderBtn').classList.remove('hidden');
        document.getElementById('profileIcon').classList.add('hidden');
    }
});

// Event Listeners
elements.loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        await login(email, password);
        showToast('Login successful!', 'success');
    } catch (error) {
        showToast('Login failed: ' + error.message, 'error');
    }
});

elements.signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    
    if (password.length < 6) {
        showToast('Password must be at least 6 characters', 'error');
        return;
    }
    
    try {
        await signUp(name, email, password);
        showToast('Account created! Please check your email.', 'success');
    } catch (error) {
        showToast('Signup failed: ' + error.message, 'error');
    }
});

elements.generateBtn.addEventListener('click', generateProject);
elements.voiceInputBtn.addEventListener('click', initVoiceInput);
elements.fileUploadBtn.addEventListener('click', () => elements.txtFileInput.click());
elements.txtFileInput.addEventListener('change', (e) => {
    if (e.target.files[0]) handleFileUpload(e.target.files[0]);
});
elements.copyOutputBtn.addEventListener('click', copyToClipboard);
elements.downloadOutputBtn.addEventListener('click', downloadAsPDF);
elements.logoutBtn.addEventListener('click', async () => {
    await logout();
    showToast('Logged out', 'info');
});
elements.settingsLogoutBtn.addEventListener('click', async () => {
    await logout();
    showToast('Logged out', 'info');
});
elements.changePasswordBtn.addEventListener('click', async () => {
    const newPassword = elements.newPassword.value;
    if (newPassword.length < 6) {
        showToast('Password must be at least 6 characters', 'error');
        return;
    }
    try {
        await changePassword(newPassword);
        showToast('Password updated successfully!', 'success');
        elements.newPassword.value = '';
    } catch (error) {
        showToast('Failed to update password', 'error');
    }
});

// Navigation
document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => showView(btn.dataset.view));
});

document.getElementById('showSignupLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    elements.loginCard.classList.add('hidden');
    elements.signupCard.classList.remove('hidden');
});

document.getElementById('showLoginLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    elements.signupCard.classList.add('hidden');
    elements.loginCard.classList.remove('hidden');
});

document.getElementById('pricingHeaderBtn')?.addEventListener('click', () => showView('pricing'));
document.getElementById('settingsUpgradeBtn')?.addEventListener('click', () => showView('pricing'));

document.querySelectorAll('.upgrade-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        if (!currentUser) {
            showToast('Please login first', 'error');
            return;
        }
        initPayment(btn.dataset.plan);
    });
});

// Mobile menu
elements.mobileMenuToggle?.addEventListener('click', () => {
    elements.sidebar.classList.toggle('active');
});

// Check existing session
supabase.auth.getSession().then(({ data: { session } }) => {
    if (session) {
        loadUserProfile();
        elements.authSection.classList.add('hidden');
        showView('generate');
    }
});